## Add KVS Logo Branding

Upload the attached Kendriya Vidyalaya Sangathan logo to the CDN and display it in two places.

### Steps

1. **Upload logo to CDN** — Use `lovable-assets create` on the uploaded `download.png` to generate `src/assets/kvs-logo.png.asset.json`. No binary lands in the repo.

2. **Auth page (`src/routes/auth.tsx`)** — Add the logo centered above the sign-in card, ~96–112px tall, with "Kendriya Vidyalaya" heading + "Arrangement System" subtitle below.

3. **Dashboard hero (`src/routes/_authenticated/index.tsx`)** — Add the logo (~64px) next to the welcome heading in the hero section.

4. **Header (no change)** — Skipping per your selection; only auth + dashboard get the logo.

### Technical notes

- Use `<img src={kvsLogo.url} alt="Kendriya Vidyalaya Sangathan" />` after importing the `.asset.json` pointer.
- No new dependencies, no backend changes.
