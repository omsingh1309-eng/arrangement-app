export const CLASSES = [
  "6A", "6B", "7A", "7B", "8A", "8B", "9A", "9B",
  "10A", "10B", "11A", "11B", "12A", "12B",
];

export const PERIODS = [1, 2, 3, 4, 5, 6, 7, 8];

export const DAYS = [
  { value: 1, label: "Mon" },
  { value: 2, label: "Tue" },
  { value: 3, label: "Wed" },
  { value: 4, label: "Thu" },
  { value: 5, label: "Fri" },
  { value: 6, label: "Sat" },
];

export const MAX_PERIODS_PER_DAY = 7;

export function dayOfWeekFromDate(dateStr: string): number {
  // 1 = Mon ... 6 = Sat. Sunday returns 0 (no school).
  const d = new Date(dateStr + "T00:00:00");
  const js = d.getDay(); // 0 = Sun .. 6 = Sat
  return js === 0 ? 0 : js;
}
