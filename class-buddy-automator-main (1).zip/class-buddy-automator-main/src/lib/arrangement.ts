import { MAX_PERIODS_PER_DAY } from "./schoolConstants";

export interface Teacher {
  id: string;
  name: string;
  short_code: string | null;
  subjects: string[];
}

export interface Slot {
  id: string;
  class_name: string;
  day_of_week: number;
  period: number;
  teacher_id: string | null;
  subject: string | null;
}

export interface Arrangement {
  date: string;
  period: number;
  class_name: string;
  original_teacher_id: string | null;
  substitute_teacher_id: string | null;
  subject: string | null;
}

export function generateArrangements(opts: {
  date: string;
  dayOfWeek: number;
  absentTeacherIds: Set<string>;
  allSlots: Slot[];
  allTeachers: Teacher[];
}): Arrangement[] {
  const { date, dayOfWeek, absentTeacherIds, allSlots, allTeachers } = opts;

  // Regular daily load for present teachers
  const regularLoad = new Map<string, number>();
  allTeachers.forEach((t) => regularLoad.set(t.id, 0));
  for (const s of allSlots) {
    if (
      s.day_of_week === dayOfWeek &&
      s.teacher_id &&
      !absentTeacherIds.has(s.teacher_id)
    ) {
      regularLoad.set(s.teacher_id, (regularLoad.get(s.teacher_id) ?? 0) + 1);
    }
  }

  // Teachers who regularly teach each class (any day/period)
  const classTeachers = new Map<string, Set<string>>();
  for (const s of allSlots) {
    if (!s.teacher_id) continue;
    if (!classTeachers.has(s.class_name))
      classTeachers.set(s.class_name, new Set());
    classTeachers.get(s.class_name)!.add(s.teacher_id);
  }

  // Who is busy at each period that day (regular schedule)
  const busyAtPeriod = new Map<number, Set<string>>();
  for (const s of allSlots) {
    if (s.day_of_week !== dayOfWeek || !s.teacher_id) continue;
    if (!busyAtPeriod.has(s.period)) busyAtPeriod.set(s.period, new Set());
    busyAtPeriod.get(s.period)!.add(s.teacher_id);
  }

  const arrangementsLoad = new Map<string, number>();
  allTeachers.forEach((t) => arrangementsLoad.set(t.id, 0));

  const slotsToCover = allSlots
    .filter(
      (s) =>
        s.day_of_week === dayOfWeek &&
        s.teacher_id &&
        absentTeacherIds.has(s.teacher_id),
    )
    .sort((a, b) => a.period - b.period || a.class_name.localeCompare(b.class_name));

  const result: Arrangement[] = [];

  for (const slot of slotsToCover) {
    const candidates = allTeachers.filter((t) => {
      if (absentTeacherIds.has(t.id)) return false;
      if (busyAtPeriod.get(slot.period)?.has(t.id)) return false;
      const total =
        (regularLoad.get(t.id) ?? 0) + (arrangementsLoad.get(t.id) ?? 0);
      if (total >= MAX_PERIODS_PER_DAY) return false;
      return true;
    });

    candidates.sort((a, b) => {
      const aClass = classTeachers.get(slot.class_name)?.has(a.id) ? 0 : 1;
      const bClass = classTeachers.get(slot.class_name)?.has(b.id) ? 0 : 1;
      if (aClass !== bClass) return aClass - bClass;
      // Subject match priority
      const aSubj = slot.subject && a.subjects.includes(slot.subject) ? 0 : 1;
      const bSubj = slot.subject && b.subjects.includes(slot.subject) ? 0 : 1;
      if (aSubj !== bSubj) return aSubj - bSubj;
      // Less loaded first
      const aLoad =
        (regularLoad.get(a.id) ?? 0) + (arrangementsLoad.get(a.id) ?? 0);
      const bLoad =
        (regularLoad.get(b.id) ?? 0) + (arrangementsLoad.get(b.id) ?? 0);
      return aLoad - bLoad;
    });

    const sub = candidates[0];
    if (sub) {
      arrangementsLoad.set(sub.id, (arrangementsLoad.get(sub.id) ?? 0) + 1);
      if (!busyAtPeriod.has(slot.period))
        busyAtPeriod.set(slot.period, new Set());
      busyAtPeriod.get(slot.period)!.add(sub.id);
    }

    result.push({
      date,
      period: slot.period,
      class_name: slot.class_name,
      original_teacher_id: slot.teacher_id,
      substitute_teacher_id: sub?.id ?? null,
      subject: slot.subject,
    });
  }

  return result;
}

export function computeTeacherDailyLoad(opts: {
  dayOfWeek: number;
  absentTeacherIds: Set<string>;
  allSlots: Slot[];
  arrangements: { period: number; substitute_teacher_id: string | null }[];
}) {
  const load = new Map<string, { regular: number; arrangements: number }>();
  const get = (id: string) => {
    if (!load.has(id)) load.set(id, { regular: 0, arrangements: 0 });
    return load.get(id)!;
  };
  for (const s of opts.allSlots) {
    if (
      s.day_of_week === opts.dayOfWeek &&
      s.teacher_id &&
      !opts.absentTeacherIds.has(s.teacher_id)
    ) {
      get(s.teacher_id).regular += 1;
    }
  }
  for (const a of opts.arrangements) {
    if (a.substitute_teacher_id) get(a.substitute_teacher_id).arrangements += 1;
  }
  return load;
}
