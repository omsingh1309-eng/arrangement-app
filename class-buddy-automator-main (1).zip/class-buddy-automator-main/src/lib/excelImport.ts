import * as XLSX from "xlsx";
import { CLASSES, PERIODS, DAYS } from "./schoolConstants";

export interface ParsedTeacher {
  name: string;
  short_code: string | null;
  subjects: string[];
}

export interface ParsedSlot {
  class_name: string;
  day_of_week: number;
  period: number;
  teacher_token: string | null; // short code or name; resolved later
  subject: string | null;
}

export async function readWorkbook(file: File): Promise<XLSX.WorkBook> {
  const buf = await file.arrayBuffer();
  return XLSX.read(buf, { type: "array" });
}

export function parseTeachersFile(wb: XLSX.WorkBook): ParsedTeacher[] {
  const ws = wb.Sheets[wb.SheetNames[0]];
  const rows = XLSX.utils.sheet_to_json<Record<string, any>>(ws, { defval: "" });
  const out: ParsedTeacher[] = [];
  for (const r of rows) {
    // case-insensitive lookup
    const keys = Object.keys(r);
    const get = (k: string) => {
      const found = keys.find((x) => x.toLowerCase().trim() === k);
      return found ? String(r[found] ?? "").trim() : "";
    };
    const name = get("name");
    if (!name) continue;
    const short = get("short code") || get("shortcode") || get("code");
    const subs = get("subjects") || get("subject");
    out.push({
      name,
      short_code: short || null,
      subjects: subs ? subs.split(",").map((s) => s.trim()).filter(Boolean) : [],
    });
  }
  return out;
}

const DAY_NAME_MAP: Record<string, number> = {
  mon: 1, monday: 1,
  tue: 2, tuesday: 2, tues: 2,
  wed: 3, wednesday: 3,
  thu: 4, thursday: 4, thur: 4, thurs: 4,
  fri: 5, friday: 5,
  sat: 6, saturday: 6,
};

function dayFromSheetName(name: string): number | null {
  const key = name.toLowerCase().trim();
  return DAY_NAME_MAP[key] ?? null;
}

function normalizeClass(s: string): string | null {
  const c = s.toUpperCase().replace(/\s+/g, "");
  return CLASSES.includes(c) ? c : null;
}

function parseCell(raw: string): { token: string | null; subject: string | null } {
  const v = raw.trim();
  if (!v) return { token: null, subject: null };
  // formats: "ASH-Math", "ASH/Math", "ASH | Math", or just "ASH"
  const m = v.split(/\s*[-/|]\s*/);
  if (m.length >= 2) return { token: m[0].trim(), subject: m.slice(1).join("-").trim() || null };
  return { token: v, subject: null };
}

export function parseTimetableFile(wb: XLSX.WorkBook): { slots: ParsedSlot[]; warnings: string[] } {
  const slots: ParsedSlot[] = [];
  const warnings: string[] = [];

  for (const sheetName of wb.SheetNames) {
    const day = dayFromSheetName(sheetName);
    if (!day) {
      warnings.push(`Sheet "${sheetName}" skipped — name must be Mon/Tue/Wed/Thu/Fri/Sat`);
      continue;
    }
    const ws = wb.Sheets[sheetName];
    const rows = XLSX.utils.sheet_to_json<Record<string, any>>(ws, { defval: "" });
    for (const r of rows) {
      const keys = Object.keys(r);
      const classKey = keys.find((k) => k.toLowerCase().trim() === "class");
      if (!classKey) continue;
      const cls = normalizeClass(String(r[classKey] ?? ""));
      if (!cls) continue;
      for (const p of PERIODS) {
        const pKey = keys.find((k) => {
          const lk = k.toLowerCase().trim().replace(/\s+/g, "");
          return lk === `p${p}` || lk === `period${p}` || lk === String(p);
        });
        if (!pKey) continue;
        const { token, subject } = parseCell(String(r[pKey] ?? ""));
        if (!token) continue;
        slots.push({ class_name: cls, day_of_week: day, period: p, teacher_token: token, subject });
      }
    }
  }
  return { slots, warnings };
}

export function downloadTeachersTemplate() {
  const data = [
    { Name: "A. Sharma", "Short Code": "ASH", Subjects: "Math, Science" },
    { Name: "B. Verma", "Short Code": "BVR", Subjects: "English" },
  ];
  const ws = XLSX.utils.json_to_sheet(data);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Teachers");
  XLSX.writeFile(wb, "teachers_template.xlsx");
}

export function downloadTimetableTemplate() {
  const wb = XLSX.utils.book_new();
  for (const d of DAYS) {
    const rows = CLASSES.map((c) => {
      const row: Record<string, string> = { Class: c };
      for (const p of PERIODS) row[`P${p}`] = "";
      return row;
    });
    const ws = XLSX.utils.json_to_sheet(rows);
    XLSX.utils.book_append_sheet(wb, ws, d.label);
  }
  XLSX.writeFile(wb, "timetable_template.xlsx");
}

export function resolveTeacherToken(
  token: string,
  teachers: { id: string; name: string; short_code: string | null }[],
): string | null {
  const t = token.toLowerCase().trim();
  const byCode = teachers.find((x) => (x.short_code ?? "").toLowerCase().trim() === t);
  if (byCode) return byCode.id;
  const byName = teachers.find((x) => x.name.toLowerCase().trim() === t);
  return byName?.id ?? null;
}
