import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, Grid3x3, CalendarCheck, ArrowRight } from "lucide-react";
import kvsLogo from "@/assets/kvs-logo.png.asset.json";

export const Route = createFileRoute("/_authenticated/")({
  component: Dashboard,
});

function Dashboard() {
  const { data: counts } = useQuery({
    queryKey: ["dashboard-counts"],
    queryFn: async () => {
      const [t, s, a] = await Promise.all([
        supabase.from("teachers").select("id", { count: "exact", head: true }),
        supabase.from("timetable_slots").select("id", { count: "exact", head: true }),
        supabase.from("absences").select("id", { count: "exact", head: true }).eq("date", new Date().toISOString().slice(0, 10)),
      ]);
      return {
        teachers: t.count ?? 0,
        slots: s.count ?? 0,
        absencesToday: a.count ?? 0,
      };
    },
  });

  const cards = [
    { to: "/teachers", icon: Users, label: "Teachers", desc: "Add or edit teachers and their subjects", count: counts?.teachers },
    { to: "/timetable", icon: Grid3x3, label: "Timetable", desc: "Set the regular weekly timetable", count: counts?.slots },
    { to: "/arrangements", icon: CalendarCheck, label: "Today's Arrangements", desc: "Mark absentees and auto-arrange", count: counts?.absencesToday, suffix: "absent today" },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <img src={kvsLogo.url} alt="Kendriya Vidyalaya Sangathan" className="h-16 w-16 object-contain shrink-0" />
        <div>
          <h1 className="text-3xl font-bold">Welcome 👋</h1>
          <p className="text-muted-foreground">Manage your school's daily teacher arrangements.</p>
        </div>
      </div>
      <div className="grid gap-4 md:grid-cols-3">
        {cards.map((c) => (
          <Link key={c.to} to={c.to} className="group">
            <Card className="h-full transition-all hover:shadow-md hover:border-primary/50">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-base font-medium">{c.label}</CardTitle>
                <c.icon className="h-5 w-5 text-primary" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{c.count ?? "—"}</div>
                <p className="text-xs text-muted-foreground mt-1">{c.suffix ?? c.desc}</p>
                <div className="flex items-center text-xs text-primary mt-3 opacity-0 group-hover:opacity-100 transition-opacity">
                  Open <ArrowRight className="h-3 w-3 ml-1" />
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
      <Card>
        <CardHeader><CardTitle className="text-base">How it works</CardTitle></CardHeader>
        <CardContent className="text-sm text-muted-foreground space-y-2">
          <p>1. Add all teachers in <strong>Teachers</strong>.</p>
          <p>2. Fill the weekly schedule in <strong>Timetable</strong> (one entry per class, day &amp; period).</p>
          <p>3. Each day, open <strong>Arrangements</strong>, mark absent teachers, and click <em>Generate</em>. You can shuffle any cell.</p>
          <p className="pt-1">Priority: regular class teachers first → subject match → lighter load. No teacher is given more than 7 periods in a day.</p>
        </CardContent>
      </Card>
    </div>
  );
}
