import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus, Trash2, Pencil, Upload, Download } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { useRef } from "react";
import { readWorkbook, parseTeachersFile, downloadTeachersTemplate } from "@/lib/excelImport";

export const Route = createFileRoute("/_authenticated/teachers")({
  component: TeachersPage,
});

interface Teacher {
  id: string;
  name: string;
  short_code: string | null;
  subjects: string[];
}

function TeachersPage() {
  const qc = useQueryClient();
  const { data: teachers = [], isLoading } = useQuery({
    queryKey: ["teachers"],
    queryFn: async () => {
      const { data, error } = await supabase.from("teachers").select("*").order("name");
      if (error) throw error;
      return data as Teacher[];
    },
  });

  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Teacher | null>(null);
  const [name, setName] = useState("");
  const [shortCode, setShortCode] = useState("");
  const [subjects, setSubjects] = useState("");

  const reset = () => { setEditing(null); setName(""); setShortCode(""); setSubjects(""); };

  const openNew = () => { reset(); setOpen(true); };
  const openEdit = (t: Teacher) => {
    setEditing(t); setName(t.name); setShortCode(t.short_code ?? ""); setSubjects(t.subjects.join(", "));
    setOpen(true);
  };

  const save = async () => {
    if (!name.trim()) return toast.error("Name required");
    const payload = {
      name: name.trim(),
      short_code: shortCode.trim() || null,
      subjects: subjects.split(",").map((s) => s.trim()).filter(Boolean),
    };
    const { error } = editing
      ? await supabase.from("teachers").update(payload).eq("id", editing.id)
      : await supabase.from("teachers").insert(payload);
    if (error) return toast.error(error.message);
    toast.success(editing ? "Teacher updated" : "Teacher added");
    setOpen(false); reset();
    qc.invalidateQueries({ queryKey: ["teachers"] });
  };

  const remove = async (id: string) => {
    if (!confirm("Delete this teacher? Their timetable entries will be cleared.")) return;
    const { error } = await supabase.from("teachers").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Deleted");
    qc.invalidateQueries({ queryKey: ["teachers"] });
  };

  const fileRef = useRef<HTMLInputElement>(null);
  const handleImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    try {
      const wb = await readWorkbook(file);
      const parsed = parseTeachersFile(wb);
      if (parsed.length === 0) return toast.error("No valid rows found. Need a 'Name' column.");
      const { data: existing } = await supabase.from("teachers").select("name");
      const existingNames = new Set((existing ?? []).map((t) => t.name.toLowerCase()));
      const toInsert = parsed.filter((t) => !existingNames.has(t.name.toLowerCase()));
      const skipped = parsed.length - toInsert.length;
      if (toInsert.length === 0) return toast.info(`All ${parsed.length} teachers already exist.`);
      const { error } = await supabase.from("teachers").insert(toInsert);
      if (error) return toast.error(error.message);
      toast.success(`Imported ${toInsert.length} teacher(s)${skipped ? `, skipped ${skipped} duplicate(s)` : ""}.`);
      qc.invalidateQueries({ queryKey: ["teachers"] });
    } catch (err: any) {
      toast.error("Import failed: " + (err?.message ?? String(err)));
    }
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between flex-wrap gap-2">
        <CardTitle>Teachers</CardTitle>
        <div className="flex gap-2 flex-wrap">
        <input ref={fileRef} type="file" accept=".xlsx,.xls,.csv" className="hidden" onChange={handleImport} />
        <Button variant="outline" onClick={() => downloadTeachersTemplate()}>
          <Download className="h-4 w-4 mr-1" /> Template
        </Button>
        <Button variant="outline" onClick={() => fileRef.current?.click()}>
          <Upload className="h-4 w-4 mr-1" /> Import Excel
        </Button>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button onClick={openNew}><Plus className="h-4 w-4 mr-1" /> Add Teacher</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>{editing ? "Edit" : "Add"} Teacher</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <div className="space-y-1">
                <Label>Name</Label>
                <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. A. Sharma" />
              </div>
              <div className="space-y-1">
                <Label>Short code (optional)</Label>
                <Input value={shortCode} onChange={(e) => setShortCode(e.target.value)} placeholder="e.g. ASH" maxLength={6} />
              </div>
              <div className="space-y-1">
                <Label>Subjects (comma-separated)</Label>
                <Input value={subjects} onChange={(e) => setSubjects(e.target.value)} placeholder="Math, Science" />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
              <Button onClick={save}>Save</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? <p className="text-muted-foreground">Loading…</p> : teachers.length === 0 ? (
          <p className="text-muted-foreground text-center py-8">No teachers yet. Click "Add Teacher" to start.</p>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Code</TableHead>
                <TableHead>Subjects</TableHead>
                <TableHead className="w-24" />
              </TableRow>
            </TableHeader>
            <TableBody>
              {teachers.map((t) => (
                <TableRow key={t.id}>
                  <TableCell className="font-medium">{t.name}</TableCell>
                  <TableCell>{t.short_code ?? "—"}</TableCell>
                  <TableCell>
                    <div className="flex flex-wrap gap-1">
                      {t.subjects.length === 0 ? <span className="text-muted-foreground text-sm">—</span> :
                        t.subjects.map((s) => <Badge key={s} variant="secondary">{s}</Badge>)}
                    </div>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button size="icon" variant="ghost" onClick={() => openEdit(t)}><Pencil className="h-4 w-4" /></Button>
                    <Button size="icon" variant="ghost" onClick={() => remove(t.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );
}
