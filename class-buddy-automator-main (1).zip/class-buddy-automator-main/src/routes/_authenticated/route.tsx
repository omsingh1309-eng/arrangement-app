import { createFileRoute, Outlet, redirect, Link } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { CalendarCheck, Users, Grid3x3, LogOut, LayoutDashboard } from "lucide-react";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  beforeLoad: async () => {
    const { data, error } = await supabase.auth.getUser();
    if (error || !data.user) throw redirect({ to: "/auth" });
    return { user: data.user };
  },
  component: AuthLayout,
});

function AuthLayout() {
  const handleLogout = async () => {
    await supabase.auth.signOut();
    window.location.href = "/auth";
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-card sticky top-0 z-10 shadow-sm">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between gap-4">
          <Link to="/" className="font-bold text-lg flex items-center gap-2">
            <CalendarCheck className="h-5 w-5 text-primary" />
            <span>School Arrangement</span>
          </Link>
          <nav className="flex items-center gap-1">
            <NavLink to="/" icon={<LayoutDashboard className="h-4 w-4" />} label="Home" />
            <NavLink to="/teachers" icon={<Users className="h-4 w-4" />} label="Teachers" />
            <NavLink to="/timetable" icon={<Grid3x3 className="h-4 w-4" />} label="Timetable" />
            <NavLink to="/arrangements" icon={<CalendarCheck className="h-4 w-4" />} label="Arrangements" />
            <Button variant="ghost" size="sm" onClick={handleLogout} className="ml-2">
              <LogOut className="h-4 w-4" />
            </Button>
          </nav>
        </div>
      </header>
      <main className="container mx-auto px-4 py-6">
        <Outlet />
      </main>
    </div>
  );
}

function NavLink({ to, icon, label }: { to: string; icon: React.ReactNode; label: string }) {
  return (
    <Link
      to={to}
      className="px-3 py-2 text-sm font-medium rounded-md hover:bg-accent flex items-center gap-2 [&.active]:bg-accent [&.active]:text-accent-foreground"
      activeOptions={{ exact: true }}
    >
      {icon}
      <span className="hidden sm:inline">{label}</span>
    </Link>
  );
}
