import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Sparkles, Trash2 } from "lucide-react";
import { toast } from "sonner";
import {
  generateArrangements, computeTeacherDailyLoad,
  type Teacher, type Slot, type Arrangement,
} from "@/lib/arrangement";
import { dayOfWeekFromDate, DAYS, MAX_PERIODS_PER_DAY } from "@/lib/schoolConstants";

export const Route = createFileRoute("/_authenticated/arrangements")({
  component: ArrangementsPage,
});

function todayStr() { return new Date().toISOString().slice(0, 10); }

function ArrangementsPage() {
  const qc = useQueryClient();
  const [date, setDate] = useState(todayStr());
  const dow = dayOfWeekFromDate(date);
  const dayLabel = DAYS.find((d) => d.value === dow)?.label;

  const { data: teachers = [] } = useQuery({
    queryKey: ["teachers"],
    queryFn: async () => {
      const { data, error } = await supabase.from("teachers").select("id,name,short_code,subjects").order("name");
      if (error) throw error;
      return data as Teacher[];
    },
  });

  const { data: allSlots = [] } = useQuery({
    queryKey: ["all-slots"],
    queryFn: async () => {
      const { data, error } = await supabase.from("timetable_slots").select("*");
      if (error) throw error;
      return data as Slot[];
    },
  });

  const { data: absences = [] } = useQuery({
    queryKey: ["absences", date],
    queryFn: async () => {
      const { data, error } = await supabase.from("absences").select("*").eq("date", date);
      if (error) throw error;
      return data as { id: string; teacher_id: string; date: string }[];
    },
  });

  const { data: arrangements = [] } = useQuery({
    queryKey: ["arrangements", date],
    queryFn: async () => {
      const { data, error } = await supabase.from("arrangements")
        .select("*").eq("date", date).order("period").order("class_name");
      if (error) throw error;
      return data as (Arrangement & { id: string })[];
    },
  });

  const absentSet = useMemo(() => new Set(absences.map((a) => a.teacher_id)), [absences]);
  const teacherById = useMemo(() => {
    const m = new Map<string, Teacher>();
    teachers.forEach((t) => m.set(t.id, t));
    return m;
  }, [teachers]);

  const dailyLoad = useMemo(
    () => computeTeacherDailyLoad({ dayOfWeek: dow, absentTeacherIds: absentSet, allSlots, arrangements }),
    [dow, absentSet, allSlots, arrangements],
  );

  const toggleAbsent = async (teacherId: string, checked: boolean) => {
    if (checked) {
      const { error } = await supabase.from("absences").insert({ date, teacher_id: teacherId });
      if (error) return toast.error(error.message);
    } else {
      const { error } = await supabase.from("absences").delete().eq("date", date).eq("teacher_id", teacherId);
      if (error) return toast.error(error.message);
    }
    qc.invalidateQueries({ queryKey: ["absences", date] });
  };

  const generate = async () => {
    if (dow === 0) return toast.error("Sunday has no schedule.");
    if (absences.length === 0) return toast.error("Mark at least one absent teacher.");
    const result = generateArrangements({
      date, dayOfWeek: dow, absentTeacherIds: absentSet, allSlots, allTeachers: teachers,
    });
    // Clear old & insert new (upsert by unique (date,period,class_name))
    await supabase.from("arrangements").delete().eq("date", date);
    if (result.length) {
      const { error } = await supabase.from("arrangements").insert(result);
      if (error) return toast.error(error.message);
    }
    toast.success(`Generated ${result.length} arrangement${result.length !== 1 ? "s" : ""}`);
    qc.invalidateQueries({ queryKey: ["arrangements", date] });
  };

  const changeSubstitute = async (id: string, newTeacherId: string | null) => {
    const { error } = await supabase.from("arrangements").update({ substitute_teacher_id: newTeacherId }).eq("id", id);
    if (error) return toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["arrangements", date] });
  };

  const clearAll = async () => {
    if (!confirm("Clear all arrangements for this date?")) return;
    const { error } = await supabase.from("arrangements").delete().eq("date", date);
    if (error) return toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["arrangements", date] });
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>Daily Arrangement</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-wrap gap-4 items-end">
            <div className="space-y-1">
              <Label>Date</Label>
              <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="w-44" />
            </div>
            <div className="text-sm">
              <div className="text-muted-foreground">Day</div>
              <div className="font-medium">{dow === 0 ? "Sunday (off)" : dayLabel}</div>
            </div>
            <div className="flex-1" />
            <Button onClick={generate} disabled={dow === 0}>
              <Sparkles className="h-4 w-4 mr-1" /> Generate Arrangements
            </Button>
            {arrangements.length > 0 && (
              <Button variant="outline" onClick={clearAll}>
                <Trash2 className="h-4 w-4 mr-1" /> Clear
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="text-base">Mark Absent Teachers</CardTitle></CardHeader>
        <CardContent>
          {teachers.length === 0 ? (
            <p className="text-muted-foreground text-sm">No teachers yet.</p>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2">
              {teachers.map((t) => (
                <label key={t.id} className="flex items-center gap-2 p-2 rounded hover:bg-accent cursor-pointer">
                  <Checkbox
                    checked={absentSet.has(t.id)}
                    onCheckedChange={(c) => toggleAbsent(t.id, Boolean(c))}
                  />
                  <span className="text-sm">{t.short_code ? `${t.short_code} · ` : ""}{t.name}</span>
                </label>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            Arrangements
            <Badge variant="secondary">{arrangements.length}</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {arrangements.length === 0 ? (
            <p className="text-muted-foreground text-sm text-center py-6">
              Mark absent teachers above and click <strong>Generate</strong>.
            </p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm border-collapse">
                <thead>
                  <tr className="bg-muted">
                    <th className="border p-2 text-left">Period</th>
                    <th className="border p-2 text-left">Class</th>
                    <th className="border p-2 text-left">Subject</th>
                    <th className="border p-2 text-left">Absent Teacher</th>
                    <th className="border p-2 text-left">Substitute</th>
                  </tr>
                </thead>
                <tbody>
                  {arrangements.map((a) => {
                    const orig = a.original_teacher_id ? teacherById.get(a.original_teacher_id) : null;
                    // Eligible substitutes: not absent, not teaching same period, not over cap
                    const busyAtPeriod = new Set(
                      allSlots.filter((s) => s.day_of_week === dow && s.period === a.period && s.teacher_id).map((s) => s.teacher_id!),
                    );
                    // Other arrangements this period
                    arrangements.filter((x) => x.id !== a.id && x.period === a.period && x.substitute_teacher_id)
                      .forEach((x) => busyAtPeriod.add(x.substitute_teacher_id!));
                    return (
                      <tr key={a.id}>
                        <td className="border p-2">{a.period}</td>
                        <td className="border p-2 font-medium">{a.class_name}</td>
                        <td className="border p-2">{a.subject ?? "—"}</td>
                        <td className="border p-2 text-destructive">{orig?.name ?? "—"}</td>
                        <td className="border p-2">
                          <Select
                            value={a.substitute_teacher_id ?? "none"}
                            onValueChange={(v) => changeSubstitute(a.id, v === "none" ? null : v)}
                          >
                            <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                            <SelectContent>
                              <SelectItem value="none">— Unassigned —</SelectItem>
                              {teachers.filter((t) => !absentSet.has(t.id)).map((t) => {
                                const load = dailyLoad.get(t.id) ?? { regular: 0, arrangements: 0 };
                                const total = load.regular + load.arrangements;
                                const busy = busyAtPeriod.has(t.id);
                                const over = total >= MAX_PERIODS_PER_DAY && a.substitute_teacher_id !== t.id;
                                return (
                                  <SelectItem key={t.id} value={t.id} disabled={busy || over}>
                                    {t.name} ({total}/{MAX_PERIODS_PER_DAY}){busy ? " · busy" : ""}{over ? " · full" : ""}
                                  </SelectItem>
                                );
                              })}
                            </SelectContent>
                          </Select>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
