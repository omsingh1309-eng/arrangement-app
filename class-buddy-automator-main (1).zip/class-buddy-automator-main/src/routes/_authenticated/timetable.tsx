import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useMemo, useState, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { CLASSES, PERIODS, DAYS } from "@/lib/schoolConstants";
import { toast } from "sonner";
import { Upload, Download } from "lucide-react";
import {
  readWorkbook,
  parseTimetableFile,
  downloadTimetableTemplate,
  resolveTeacherToken,
} from "@/lib/excelImport";

export const Route = createFileRoute("/_authenticated/timetable")({
  component: TimetablePage,
});

interface Teacher { id: string; name: string; short_code: string | null; }
interface Slot { id: string; class_name: string; day_of_week: number; period: number; teacher_id: string | null; subject: string | null; }

function TimetablePage() {
  const qc = useQueryClient();
  const [day, setDay] = useState(1);

  const { data: teachers = [] } = useQuery({
    queryKey: ["teachers"],
    queryFn: async () => {
      const { data, error } = await supabase.from("teachers").select("id,name,short_code").order("name");
      if (error) throw error;
      return data as Teacher[];
    },
  });

  const { data: slots = [] } = useQuery({
    queryKey: ["slots", day],
    queryFn: async () => {
      const { data, error } = await supabase.from("timetable_slots").select("*").eq("day_of_week", day);
      if (error) throw error;
      return data as Slot[];
    },
  });

  const slotMap = useMemo(() => {
    const m = new Map<string, Slot>();
    for (const s of slots) m.set(`${s.class_name}|${s.period}`, s);
    return m;
  }, [slots]);

  const upsert = async (className: string, period: number, teacherId: string | null, subject: string | null) => {
    const existing = slotMap.get(`${className}|${period}`);
    if (!teacherId && !subject && existing) {
      const { error } = await supabase.from("timetable_slots").delete().eq("id", existing.id);
      if (error) return toast.error(error.message);
    } else {
      const payload = { class_name: className, day_of_week: day, period, teacher_id: teacherId, subject };
      const { error } = existing
        ? await supabase.from("timetable_slots").update(payload).eq("id", existing.id)
        : await supabase.from("timetable_slots").insert(payload);
      if (error) return toast.error(error.message);
    }
    qc.invalidateQueries({ queryKey: ["slots", day] });
  };

  const fileRef = useRef<HTMLInputElement>(null);
  const handleImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    if (!confirm("This will REPLACE the existing timetable for the days present in the file. Continue?")) return;
    try {
      const wb = await readWorkbook(file);
      const { slots: parsed, warnings } = parseTimetableFile(wb);
      if (parsed.length === 0) return toast.error("No valid slots found. Check the template format.");
      const { data: teachersAll } = await supabase.from("teachers").select("id,name,short_code");
      const unknown = new Set<string>();
      const rows = parsed.map((s) => {
        const tid = resolveTeacherToken(s.teacher_token!, teachersAll ?? []);
        if (!tid) unknown.add(s.teacher_token!);
        return {
          class_name: s.class_name,
          day_of_week: s.day_of_week,
          period: s.period,
          teacher_id: tid,
          subject: s.subject,
        };
      });
      const affectedDays = Array.from(new Set(rows.map((r) => r.day_of_week)));
      const { error: delErr } = await supabase.from("timetable_slots").delete().in("day_of_week", affectedDays);
      if (delErr) return toast.error(delErr.message);
      const { error: insErr } = await supabase.from("timetable_slots").insert(rows);
      if (insErr) return toast.error(insErr.message);
      toast.success(
        `Imported ${rows.length} slots across ${affectedDays.length} day(s).` +
          (unknown.size ? ` Unknown teachers (left blank): ${Array.from(unknown).join(", ")}` : ""),
      );
      if (warnings.length) warnings.forEach((w) => toast.warning(w));
      qc.invalidateQueries({ queryKey: ["slots"] });
    } catch (err: any) {
      toast.error("Import failed: " + (err?.message ?? String(err)));
    }
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-4 flex-wrap">
        <CardTitle>Weekly Timetable</CardTitle>
        <div className="flex items-center gap-2 flex-wrap">
          <input ref={fileRef} type="file" accept=".xlsx,.xls,.csv" className="hidden" onChange={handleImport} />
          <Button variant="outline" size="sm" onClick={() => downloadTimetableTemplate()}>
            <Download className="h-4 w-4 mr-1" /> Template
          </Button>
          <Button variant="outline" size="sm" onClick={() => fileRef.current?.click()}>
            <Upload className="h-4 w-4 mr-1" /> Import / Update
          </Button>
          <span className="text-sm text-muted-foreground ml-2">Day:</span>
          <Select value={String(day)} onValueChange={(v) => setDay(Number(v))}>
            <SelectTrigger className="w-32"><SelectValue /></SelectTrigger>
            <SelectContent>
              {DAYS.map((d) => <SelectItem key={d.value} value={String(d.value)}>{d.label}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent>
        {teachers.length === 0 ? (
          <p className="text-center text-muted-foreground py-8">Add teachers first in the Teachers page.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full border-collapse text-sm">
              <thead>
                <tr>
                  <th className="border bg-muted p-2 text-left sticky left-0 z-10">Class</th>
                  {PERIODS.map((p) => (
                    <th key={p} className="border bg-muted p-2 text-center min-w-40">Period {p}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {CLASSES.map((c) => (
                  <tr key={c}>
                    <td className="border bg-muted/50 p-2 font-medium sticky left-0">{c}</td>
                    {PERIODS.map((p) => {
                      const slot = slotMap.get(`${c}|${p}`);
                      return (
                        <td key={p} className="border p-1 align-top">
                          <SlotEditor
                            teachers={teachers}
                            teacherId={slot?.teacher_id ?? null}
                            subject={slot?.subject ?? ""}
                            onChange={(tid, sub) => upsert(c, p, tid, sub || null)}
                          />
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function SlotEditor({ teachers, teacherId, subject, onChange }: {
  teachers: Teacher[]; teacherId: string | null; subject: string;
  onChange: (teacherId: string | null, subject: string) => void;
}) {
  const [localSub, setLocalSub] = useState(subject);
  return (
    <div className="space-y-1">
      <Select value={teacherId ?? "none"} onValueChange={(v) => onChange(v === "none" ? null : v, localSub)}>
        <SelectTrigger className="h-8 text-xs"><SelectValue placeholder="—" /></SelectTrigger>
        <SelectContent>
          <SelectItem value="none">— Free —</SelectItem>
          {teachers.map((t) => (
            <SelectItem key={t.id} value={t.id}>
              {t.short_code ? `${t.short_code} · ${t.name}` : t.name}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
      <Input
        className="h-7 text-xs"
        placeholder="Subject"
        value={localSub}
        onChange={(e) => setLocalSub(e.target.value)}
        onBlur={() => { if (localSub !== subject) onChange(teacherId, localSub); }}
      />
    </div>
  );
}
