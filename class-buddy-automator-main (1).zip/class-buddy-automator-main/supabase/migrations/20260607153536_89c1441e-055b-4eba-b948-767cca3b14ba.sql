
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;

DROP POLICY IF EXISTS "auth all teachers" ON public.teachers;
CREATE POLICY "auth manage teachers" ON public.teachers FOR ALL TO authenticated
  USING (auth.uid() IS NOT NULL) WITH CHECK (auth.uid() IS NOT NULL);

DROP POLICY IF EXISTS "auth all absences" ON public.absences;
CREATE POLICY "auth manage absences" ON public.absences FOR ALL TO authenticated
  USING (auth.uid() IS NOT NULL) WITH CHECK (auth.uid() IS NOT NULL);

DROP POLICY IF EXISTS "auth all arrangements" ON public.arrangements;
CREATE POLICY "auth manage arrangements" ON public.arrangements FOR ALL TO authenticated
  USING (auth.uid() IS NOT NULL) WITH CHECK (auth.uid() IS NOT NULL);

DROP POLICY IF EXISTS "auth all timetable" ON public.timetable_slots;
CREATE POLICY "auth manage timetable" ON public.timetable_slots FOR ALL TO authenticated
  USING (auth.uid() IS NOT NULL) WITH CHECK (auth.uid() IS NOT NULL);
