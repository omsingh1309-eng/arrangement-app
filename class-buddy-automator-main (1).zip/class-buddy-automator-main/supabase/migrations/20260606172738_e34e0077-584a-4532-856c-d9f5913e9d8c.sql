
-- Profiles
CREATE TABLE public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "auth read profiles" ON public.profiles FOR SELECT TO authenticated USING (true);
CREATE POLICY "users update own profile" ON public.profiles FOR UPDATE TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

-- Teachers
CREATE TABLE public.teachers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  short_code text,
  subjects text[] NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.teachers TO authenticated;
GRANT ALL ON public.teachers TO service_role;
ALTER TABLE public.teachers ENABLE ROW LEVEL SECURITY;
CREATE POLICY "auth all teachers" ON public.teachers FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- Timetable slots
CREATE TABLE public.timetable_slots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  class_name text NOT NULL,
  day_of_week int NOT NULL CHECK (day_of_week BETWEEN 1 AND 6),
  period int NOT NULL CHECK (period BETWEEN 1 AND 8),
  teacher_id uuid REFERENCES public.teachers(id) ON DELETE SET NULL,
  subject text,
  UNIQUE(class_name, day_of_week, period)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.timetable_slots TO authenticated;
GRANT ALL ON public.timetable_slots TO service_role;
ALTER TABLE public.timetable_slots ENABLE ROW LEVEL SECURITY;
CREATE POLICY "auth all timetable" ON public.timetable_slots FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- Absences
CREATE TABLE public.absences (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  date date NOT NULL,
  teacher_id uuid NOT NULL REFERENCES public.teachers(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(date, teacher_id)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.absences TO authenticated;
GRANT ALL ON public.absences TO service_role;
ALTER TABLE public.absences ENABLE ROW LEVEL SECURITY;
CREATE POLICY "auth all absences" ON public.absences FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- Arrangements
CREATE TABLE public.arrangements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  date date NOT NULL,
  period int NOT NULL CHECK (period BETWEEN 1 AND 8),
  class_name text NOT NULL,
  original_teacher_id uuid REFERENCES public.teachers(id) ON DELETE SET NULL,
  substitute_teacher_id uuid REFERENCES public.teachers(id) ON DELETE SET NULL,
  subject text,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(date, period, class_name)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.arrangements TO authenticated;
GRANT ALL ON public.arrangements TO service_role;
ALTER TABLE public.arrangements ENABLE ROW LEVEL SECURITY;
CREATE POLICY "auth all arrangements" ON public.arrangements FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- Auto-create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.email));
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
